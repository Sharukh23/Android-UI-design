package com.example.practice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // 1.List view
    ListView listView;

    //2.Data
    String[] title = {
            "Master Android Pro",
            "Master Flutter",
            "Master Android App",
            "Youtube Channel",
            "Rate US",
            "Master Android Pro",
            "Master Flutter",
            "Master Android App",
            "Youtube Channel",
            "Rate US",
            "Master Android Pro",
            "Master Flutter",
            "Master Android App",
            "Youtube Channel",
            "Rate US"
    };

    String[] description = {
            "Learn android app development from zero to hero",
            "Learn flutter from Scratch",
            "Helping more than 780,000+ Developers to learn android",
            "Android MasterApp is our official channel",
            "Keep us making new tutorials, Rate us 5 stars on Udemy",
            "Learn android app development from zero to hero",
            "Learn flutter from Scratch",
            "Helping more than 780,000+ Developers to learn android",
            "Android MasterApp is our official channel",
            "Keep us making new tutorials, Rate us 5 stars on Udemy",
            "Learn android app development from zero to hero",
            "Learn flutter from Scratch",
            "Helping more than 780,000+ Developers to learn android",
            "Android MasterApp is our official channel",
            "Keep us making new tutorials, Rate us 5 stars on Udemy"
    };

    //Images as an array
    Integer[] imags = {
            R.drawable.image,
            R.drawable.peakpx,
            R.drawable.superman,
            R.drawable.kanji,
            R.drawable.black_panther,
            R.drawable.image,
            R.drawable.peakpx,
            R.drawable.superman,
            R.drawable.kanji,
            R.drawable.black_panther,
            R.drawable.image,
            R.drawable.peakpx,
            R.drawable.superman,
            R.drawable.kanji,
            R.drawable.black_panther

    };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        MyListAdapter adapter = new MyListAdapter(
                this,
                title,
                description,
                imags);



        listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);

        // handling click events on items
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                //item 1 select

                if (i == 0){
                    Toast.makeText(MainActivity.this, "Item 1 selected", Toast.LENGTH_SHORT).show();
                }
                //item 2 select

                if (i == 1){
                    Toast.makeText(MainActivity.this, "Item 2 selected", Toast.LENGTH_SHORT).show();
                }
                //item 3 select

                if (i == 2){
                    Toast.makeText(MainActivity.this, "Item 3 selected", Toast.LENGTH_SHORT).show();
                }
                //item 4 select

                if (i == 3){
                    Toast.makeText(MainActivity.this, "Item 4 selected", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
}